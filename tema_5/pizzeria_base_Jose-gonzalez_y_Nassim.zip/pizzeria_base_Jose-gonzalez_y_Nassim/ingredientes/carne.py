from ingredientes.ingrediente import Ingrediente

class Carne(Ingrediente):
    def __init__(self, nombre="Carne"):
        super(). __init__(nombre, "🥩")
